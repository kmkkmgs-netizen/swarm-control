// src/services/esp32Service.ts
import type { CommunicationService } from './communicationService'
import type { Movement, Robot, SwarmConfig, SwarmEvent, SwarmState } from '../types/robot'
import { initialConfig, initialRobots } from '../data/mockRobots'

type Listener = (state: SwarmState) => void

const now = () => {
  const d = new Date()
  const p = (n: number) => String(n).padStart(2, '0')
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
}

// 브릿지 서버 주소 (나중에 배포 환경에 맞게 바꿀 수 있음)
const BRIDGE_URL = 'ws://localhost:8080'

class Esp32Service implements CommunicationService {
  private state: SwarmState = {
    robots: initialRobots.map((r) => ({ ...r, status: 'OFFLINE' })), // 실제 연결 전까진 전부 OFFLINE으로 시작
    swarmStatus: 'NORMAL',
    electionStatus: 'IDLE',
    electionStep: 0,
    newLeaderId: null,
    events: [],
    config: { ...initialConfig },
  }
  private listeners = new Set<Listener>()
  private eventId = 0
  private ws: WebSocket | null = null

  constructor() {
    this.connect()
  }

  private connect() {
    this.ws = new WebSocket(BRIDGE_URL)

    this.ws.onopen = () => {
      this.log({ type: 'SYSTEM', robotId: null, message: '브릿지 서버에 연결됨' })
    }

    this.ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data)
        this.handleMessage(msg)
      } catch (e) {
        console.error('메시지 파싱 실패:', event.data)
      }
    }

    this.ws.onclose = () => {
      this.log({ type: 'SYSTEM', robotId: null, message: '브릿지 서버 연결 끊김, 재연결 시도...' })
      setTimeout(() => this.connect(), 3000)
    }

    this.ws.onerror = () => {
      this.ws?.close()
    }
  }

  // "robotId=01,role=follower,battery=80,status=ok" 같은 문자열을 객체로 변환
  private parseRobotData(raw: string): Record<string, string> {
    const result: Record<string, string> = {}
    raw.split(',').forEach((pair) => {
      const [key, value] = pair.split('=')
      if (key && value !== undefined) result[key.trim()] = value.trim()
    })
    return result
  }

  private handleMessage(msg: { type: string; data?: string; status?: string }) {
    if (msg.type === 'robot' && msg.data) {
      const parsed = this.parseRobotData(msg.data)
      if (!parsed.robotId) return

      const id = `R${parsed.robotId}` // "01" -> "R01"
      const robot = this.state.robots.find((r) => r.id === id)
      if (!robot) return

      if (parsed.role) robot.role = parsed.role.toUpperCase() as Robot['role']
      if (parsed.battery) robot.battery = Number(parsed.battery)
      if (parsed.status) robot.status = parsed.status === 'ok' ? 'ONLINE' : 'OFFLINE'
      robot.heartbeat = 'ACTIVE'

      this.emit()
    }

    if (msg.type === 'esp32') {
      this.log({
        type: 'SYSTEM',
        robotId: null,
        message: msg.status === 'connected' ? '로봇 연결됨' : '로봇 연결 끊김',
      })
    }
  }

  /* ---------- CommunicationService 구현 ---------- */

  subscribe = (listener: Listener) => {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  getState = (): SwarmState => this.state

  private emit() {
    this.state = { ...this.state }
    this.listeners.forEach((l) => l(this.state))
  }

  private log(event: Omit<SwarmEvent, 'id' | 'time'>) {
    const entry: SwarmEvent = { id: ++this.eventId, time: now(), ...event }
    this.state.events = [entry, ...this.state.events]
    this.emit()
  }

  setMovement = (robotId: string, movement: Movement) => {
    const commandMap: Record<Movement, string> = {
      STOP: 'DTS',
      FORWARD: 'forward',
      BACKWARD: 'backward',
      LEFT: 'left 10',
      RIGHT: 'right 10',
    }
    this.ws?.send(commandMap[movement])
  }

  // 아래 두 개는 지금은 실제 로봇에서 자동 판단할 기능이 없어서 동작 없음 (나중에 로봇 쪽 로직 붙으면 구현)
  simulateLeaderFailure = () => {
    console.warn('실제 로봇 모드에서는 Leader Failure를 수동으로 시뮬레이션할 수 없습니다.')
  }

  updateConfig = (config: Partial<SwarmConfig>) => {
    this.state.config = { ...this.state.config, ...config }
    this.emit()
  }

  reset = () => {
    console.warn('실제 로봇 모드에서는 reset이 지원되지 않습니다.')
  }
}

export const esp32Service = new Esp32Service()